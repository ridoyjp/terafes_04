/* TTC School Knowledge Base — last checked 2026-10-19; teacher approval required for festival updates */
export const SCHOOL_DATA = {
  "project": "TTC 学園祭 AI Chat Bot",
  "school": "専門学校東京テクニカルカレッジ",
  "checked_on": "2026-10-19",
  "official_home": "https://tec.ttc.ac.jp/",
  "status": "学校一般情報は公開された公式ページに基づく。学園祭2026の詳細は担当教員の確認が必要。",
  "entries": [
    {
      "topic": "校長・理事長（学校の責任者）",
      "keywords": [
        "校長",
        "校長先生",
        "学校長",
        "理事長",
        "学園長",
        "principal",
        "president",
        "kouchou",
        "kocho",
        "fukukouchou",
        "sensei",
        "rijichou",
        "rijicho",
        "teacher",
        "শিক্ষক",
        "প্রধান শিক্ষক",
        "誰",
        "dare"
      ],
      "text": "専門学校東京テクニカルカレッジの校長は白井 雅哲（しらい まさあき）先生。学校法人小山学園の理事長は山本 匡（やまもと ただし）氏。両者は別の役職。副校長・学科長・担当教員の最新氏名は公開資料で確認できない限り断定しない。",
      "source": "https://tec.ttc.ac.jp/school/principle/ ; https://tec.ttc.ac.jp/news/nid15775/",
      "verified": true
    },
    {
      "topic": "学校の行き方（駅別）",
      "keywords": [
        "higashi nakano",
        "nakano",
        "eki",
        "ikikata",
        "doko",
        "access",
        "東中野",
        "落合駅",
        "中井駅",
        "新宿駅",
        "電車",
        "道順",
        "駅",
        "行き方"
      ],
      "text": "JR中央・総武線『東中野駅』東口駅前、都営大江戸線『東中野駅』A1出口徒歩約1分、東京メトロ東西線『落合駅』徒歩約8分、西武新宿線『中井駅』徒歩約13分。〒164-8787 東京都中野区東中野4-2-3。",
      "source": "https://tec.ttc.ac.jp/school/access/",
      "verified": true
    },
    {
      "topic": "学校の歴史と設立年の注意",
      "keywords": [
        "history",
        "rekishi",
        "創立",
        "歴史",
        "小山学園",
        "学校法人",
        "設立"
      ],
      "text": "学校法人小山学園は50年以上の歴史を持つ運営法人。東京テクニカルカレッジ単体の創立年数と混同しない。最新の学校紹介ページを確認する。",
      "source": "https://tec.ttc.ac.jp/school/",
      "verified": true
    },
    {
      "topic":"学科一覧（公式2026年10月確認）",
      "keywords":["学科一覧","学科","コース","departments","courses","কোর্স","বিভাগ","科目"],
      "text":"学校公式サイトでは3分野11学科を案内。建築・インテリア：建築監督科（4年）、建築科（2年）、インテリア科（2年）、通信制 建築科／建築士専科（2年）。AI・IT・ゲーム・Web：情報処理科、IoT+AI科、データサイエンス+AI科、ゲーム+デジタルクリエイター科、Web動画クリエイター科（各2年）。環境・バイオ：バイオテクノロジー科（2年）、環境インフラエンジニア科（2028年4月開講予定、2年）。夜間の建築士専科は2026年度生より募集停止。入学年度と学科の募集状況は公式情報で再確認。",
      "source":"https://tec.ttc.ac.jp/departments/","verified":true
    },
    {
      "topic":"募集要項・年度別出願",
      "keywords":["募集","募集定員","出願","願書","admissions","application","আবেদন"],
      "text":"募集定員や願書受付期間は入学年度ごとに変わる。2027年度募集要項は公式サイト https://tec.ttc.ac.jp/entrance/schedule/ を参照。学校の最新募集状況と定員を必ず確認する。",
      "source":"https://tec.ttc.ac.jp/entrance/schedule/","verified":true
    },
    {
      "topic":"学費・諸費用（年度別）",
      "keywords":["学費","授業料","費用","tuition","fees","টিউশন","ফি","教材費"],
      "text":"学費と教材・ソフトウェア費は年度、学科、学年で異なる。学費は原則年2回（3月・9月）分割での案内がある。正確な最新金額は公式学費一覧 https://tec.ttc.ac.jp/entrance/expenses/ を参照。年度の異なる数字を現在の学費と断言しないこと。",
      "source":"https://tec.ttc.ac.jp/entrance/expenses/","verified":true
    },
    {
      "topic":"公式連絡先（代表・入学）",
      "keywords":["代表電話","電話番号","問い合わせ","連絡先","telephone","contact","ফোন","যোগাযোগ"],
      "text":"学校住所：〒164-8787 東京都中野区東中野4-2-3。学校代表電話：03-3360-8881。入学相談室：0120-1969-04（公式の案内は平日9:00-19:00）、メール：info@ttc.ac.jp。最新の受付時間は公式サイトを確認。",
      "source":"https://tec.ttc.ac.jp/departments/","verified":true
    },
    {
      "topic":"学校公開資料・資格",
      "keywords":["公開情報","シラバス","履修","資格","certificate","qualification","সার্টিফিকেট"],
      "text":"学校の公開情報には学科別の履修科目、シラバス、評価資料、自己評価等のPDFがある。資格案内や目標資格は https://tec.ttc.ac.jp/recruit/qualification/ 。公開資料一覧は https://tec.ttc.ac.jp/school/disclosure/ 。資格合格や就職内定を保証するものではない。",
      "source":"https://tec.ttc.ac.jp/school/disclosure/","verified":true
    },

    {
      "topic": "概要・歴史",
      "keywords": [
        "学校",
        "概要",
        "歴史",
        "ttc",
        "college",
        "কলেজ",
        "স্কুল",
        "学校紹介"
      ],
      "text": "正式名称：専門学校東京テクニカルカレッジ。学校法人小山学園が運営する工業課程の総合専門学校。学校の公式紹介では約11,000人以上の卒業生・業界人材を輩出したと説明している。運営母体の小山学園と学校単体の創立年数を混同しないこと。",
      "source": "https://tec.ttc.ac.jp/school/",
      "verified": true
    },
    {
      "topic": "所在地・アクセス",
      "keywords": [
        "住所",
        "所在地",
        "アクセス",
        "駅",
        "行き方",
        "地図",
        "location",
        "address",
        "কোথায়",
        "যাওয়ার পথ"
      ],
      "text": "所在地：〒164-8787 東京都中野区東中野4-2-3。最寄駅は東中野駅、学校の公式サイトでは徒歩1分以内と案内。新宿駅から東中野駅へ電車で約4分との案内。学校へのアクセスと学園祭当日の入口・受付場所は別情報。",
      "source": "https://tec.ttc.ac.jp/school/campus/",
      "verified": true
    },
    {
      "topic": "電話・相談窓口",
      "keywords": [
        "電話",
        "連絡",
        "問い合わせ",
        "メール",
        "contact",
        "ফোন",
        "ইমেইল"
      ],
      "text": "学校代表電話：03-3360-8881、FAX：03-3360-8820。入学相談室：0120-1969-04（平日9:00〜19:00、土日祝休）、メール info@ttc.ac.jp。就職・求人相談（企画・渉外室）：03-3360-8828、t-kikaku@ttc.ac.jp。窓口の受付時間は変更の可能性がある。",
      "source": "https://tec.ttc.ac.jp/school/",
      "verified": true
    },
    {
      "topic": "教育理念・特徴",
      "keywords": [
        "教育理念",
        "特徴",
        "教育",
        "理念",
        "授業",
        "ক্লাস",
        "শিক্ষা"
      ],
      "text": "学校の掲げる教育理念は「できないこと、わからないことを学生のせいにしない」。実習を重視し、実務経験ある教員による担任制、就職支援などの特徴を案内している。",
      "source": "https://tec.ttc.ac.jp/school/",
      "verified": true
    },
    {
      "topic": "建築・インテリア系",
      "keywords": [
        "建築",
        "インテリア",
        "architecture",
        "interior"
      ],
      "text": "建築監督科（4年制）、建築科（2年制）、インテリア科（2年制）、［通信制］建築科／建築士専科（2年制）。建築科（夜間 建築士専科）は公式学科ページで2026年度生から募集停止と案内。",
      "source": "https://tec.ttc.ac.jp/departments/",
      "verified": true
    },
    {
      "topic": "IT・AI・ゲーム・Web系",
      "keywords": [
        "it",
        "ai",
        "情報処理",
        "プログラミング",
        "iot",
        "データサイエンス",
        "ゲーム",
        "web",
        "ওয়েব",
        "আইটি",
        "প্রোগ্রামিং"
      ],
      "text": "情報処理科（2年制）、IoT+AI科（2年制）、データサイエンス+AI科（2年制）、ゲーム+デジタルクリエイター科（2年制）、Web動画クリエイター科（2年制）。各学科の詳細カリキュラム・募集状況は公式学科ページを参照。",
      "source": "https://tec.ttc.ac.jp/departments/",
      "verified": true
    },
    {
      "topic": "環境・バイオ系",
      "keywords": [
        "環境",
        "バイオ",
        "bio",
        "environment",
        "জীববিজ্ঞান"
      ],
      "text": "バイオテクノロジー科（2年制）。環境インフラエンジニア科（2年制）は公式サイトで2028年4月開講予定と案内。",
      "source": "https://tec.ttc.ac.jp/departments/",
      "verified": true
    },
    {
      "topic": "施設・設備",
      "keywords": [
        "施設",
        "設備",
        "カフェ",
        "テラカフェ",
        "テラホール",
        "学生ホール",
        "ল্যাব",
        "facility",
        "campus"
      ],
      "text": "1階のテラカフェはRJPで学生がつくったカフェ。テラホールは200名収容のホール。学生ホールは自習や休憩のためのスペース。これらの施設が学園祭当日利用可能かどうかは未確認。",
      "source": "https://tec.ttc.ac.jp/school/campus/",
      "verified": true
    },
    {
      "topic": "入学案内",
      "keywords": [
        "入学",
        "出願",
        "募集",
        "application",
        "admission",
        "ভর্তি",
        "আবেদন"
      ],
      "text": "公式入学案内に指定校推薦、学校推薦、一般入学、併願制度・編入学等の説明がある。募集要項、必要書類、出願期間は入学年度・出願区分によって異なるため、最新年度の公式情報を確認。",
      "source": "https://tec.ttc.ac.jp/entrance/",
      "verified": true
    },
    {
      "topic": "学費・納入方法",
      "keywords": [
        "学費",
        "授業料",
        "費用",
        "tuition",
        "fees",
        "টিউশন",
        "ফি"
      ],
      "text": "学費は学科・年度で異なる。公式学費表には入学金、前期・後期の授業料、実習費、施設費、維持費などがある。例として公式掲載表では情報処理科の初年度納入金合計1,465,000円、建築科1,435,000円と記載。ただし対象入学年度、教材費・PC費等の別途負担、特待生制度等を必ず公式ページで確認。掲載金額を全員の最終支払額と断定しない。",
      "source": "https://tec.ttc.ac.jp/entrance/expenses/",
      "verified": true
    },
    {
      "topic": "奨学金・支援制度",
      "keywords": [
        "奨学金",
        "学費サポート",
        "減免",
        "scholarship",
        "বৃত্তি"
      ],
      "text": "公式入学案内に学校独自の学費サポート、奨学金、教育ローン、高等教育の修学支援新制度、留学生向け学費減免・支援が案内されている。対象資格や募集時期・金額は制度ごとに異なるため公式案内へ。",
      "source": "https://tec.ttc.ac.jp/entrance/",
      "verified": true
    },
    {
      "topic": "留学生支援",
      "keywords": [
        "留学生",
        "ビザ",
        "国際",
        "外国人",
        "international",
        "বিদেশি",
        "ভিসা"
      ],
      "text": "留学生向け募集要項、出願書類、奨学金・学費サポート、学習・生活支援がある。4月に留学生オリエンテーションを実施し、学習・生活上の相談窓口がある。就職や在留資格に関する要件は個別状況や法令により異なるので窓口で確認。",
      "source": "https://tec.ttc.ac.jp/entrance/international-students/support/",
      "verified": true
    },
    {
      "topic": "就職・キャリア",
      "keywords": [
        "就職",
        "求人",
        "就活",
        "企業研究",
        "インターン",
        "career",
        "job",
        "চাকরি"
      ],
      "text": "就職ガイダンス、企業研究会、業界講演、インターンシップ、模擬面接、履歴書や試験対策などの支援を案内。公式ページは就職希望者の就職実績を強調しているが、年度・母数が明示されない数字を全学生への保証として説明しない。",
      "source": "https://tec.ttc.ac.jp/recruit/support/",
      "verified": true
    },
    {
      "topic": "資格取得・学習",
      "keywords": [
        "資格",
        "検定",
        "資格試験",
        "certificate",
        "পরীক্ষা"
      ],
      "text": "学校の就職・資格案内では資格取得支援が紹介されている。取得対象資格と合格実績は学科ごとに異なるため、各学科や公式「就職・資格」を参照。",
      "source": "https://tec.ttc.ac.jp/recruit/",
      "verified": true
    },
    {
      "topic": "オープンキャンパス",
      "keywords": [
        "オープンキャンパス",
        "見学",
        "体験入学",
        "open campus",
        "ভিজিট"
      ],
      "text": "公式サイトでオープンキャンパス・学校見学の情報を案内している。開催日、申込方法、空き状況は公式サイトの最新情報を確認。",
      "source": "https://tec.ttc.ac.jp/",
      "verified": true
    },
    {
      "topic": "学校生活・公式SNS",
      "keywords": [
        "学生生活",
        "イベント",
        "sns",
        "instagram",
        "youtube",
        "line",
        "x",
        "স্কুল লাইফ"
      ],
      "text": "公式サイトで授業や学生生活、イベント情報をX、LINE、YouTube、Instagram等で発信している。公式サイトを起点に最新のSNSリンクを参照。",
      "source": "https://tec.ttc.ac.jp/school/",
      "verified": true
    },
    {
      "topic": "学園祭・開催案内",
      "keywords": [
        "学園祭",
        "文化祭",
        "祭り",
        "festival",
        "উৎসব",
        "মেলা"
      ],
      "text": "TTC 学園祭2026向けチャットボットで、フード、ゲーム・体験、ステージ、会場ガイド等の案内項目がある。ただし、2026年の学園祭開催日・開催時間・受付・入場条件・公式プログラムは未提供・未検証。2026年の公式告知または担当教員提供資料で確認し、空欄を補完する。",
      "source": "https://tec.ttc.ac.jp/",
      "verified": false
    },
    {
      "topic": "学園祭フード・価格",
      "keywords": [
        "屋台",
        "食べ物",
        "フード",
        "飲み物",
        "値段",
        "メニュー",
        "food",
        "খাবার",
        "দাম"
      ],
      "text": "学園祭2026の各飲食ブース、販売メニュー、価格、アレルギー情報、営業時間、教室番号は未確認。担当教員から許可を得た出店一覧・価格表が必要。学校内テラカフェの通常案内と学園祭の屋台情報を混同しない。",
      "source": "",
      "verified": false
    },
    {
      "topic": "学園祭ステージ・イベント",
      "keywords": [
        "ステージ",
        "ライブ",
        "出演",
        "発表",
        "schedule",
        "event",
        "মঞ্চ",
        "অনুষ্ঠান"
      ],
      "text": "学園祭2026の出演者、演目、開始終了時間、ステージ会場は未確認。運営から正式なタイムテーブルと変更連絡先を取得して公開する。",
      "source": "",
      "verified": false
    },
    {
      "topic": "学園祭ゲーム・企画",
      "keywords": [
        "ゲーム",
        "体験",
        "ブース",
        "企画",
        "game",
        "খেলা",
        "প্রজেক্ট"
      ],
      "text": "学園祭2026の体験内容、参加費、対象年齢、整理券、所要時間、会場教室は未確認。担当者確認済みのブース一覧が必要。",
      "source": "",
      "verified": false
    },
    {
      "topic": "学園祭フロアマップ・安全",
      "keywords": [
        "トイレ",
        "マップ",
        "フロア",
        "教室",
        "休憩",
        "受付",
        "避難",
        "緊急",
        "map",
        "toilet",
        "টয়লেট"
      ],
      "text": "2026年学園祭のフロアマップ、トイレ、バリアフリールート、休憩場所、受付、避難出口、救護場所は未提供。学校の通常住所・施設紹介だけでは学園祭の当日配置を断定できない。運営承認済みの地図が必要。",
      "source": "",
      "verified": false
    },
    {
      "topic": "利用規則・問い合わせ",
      "keywords": [
        "写真",
        "撮影",
        "落とし物",
        "禁止",
        "rules",
        "注意",
        "হারানো"
      ],
      "text": "学園祭2026の写真撮影ルール、飲食場所、禁止事項、落とし物窓口、緊急連絡・当日変更情報は未確認。運営から当日用FAQと問い合わせ担当情報を受領する。",
      "source": "",
      "verified": false
    }
  ]
};
